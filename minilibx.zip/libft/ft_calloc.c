/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/11 17:33:51 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 16:11:16 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t nmemb, size_t size)
{
	void			*result;

	result = NULL;
	if (nmemb == 0 || size == 0)
	{
		result = (void *)malloc(sizeof(0));
		if (result == NULL)
			return (0);
		return (result);
	}
	result = malloc(size * nmemb);
	if (result == 0)
		return (NULL);
	ft_bzero((void *)result, nmemb * size);
	return (result);
}
