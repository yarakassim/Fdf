/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/11 16:55:58 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 18:22:21 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	unsigned int	result;
	unsigned int	i;
	unsigned int	j;

	j = 0;
	result = 0;
	i = 0;
	while (dst[i] && i <= size)
		i++;
	if (size >= i)
		result = i + ft_strlen(src);
	else
		return (size + ft_strlen(src));
	while (i < size - 1 && size > 0 && src[j])
	{
		dst[i] = src[j];
		j++;
		i++;
	}
	dst[i] = '\0';
	return (result);
}
