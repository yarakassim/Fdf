/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/13 18:52:14 by eli               #+#    #+#             */
/*   Updated: 2021/05/20 13:50:50 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_len(int nbr)
{
	int	len;

	len = 1;
	if (nbr < 0)
	{
		if (nbr == -2147483648)
			nbr = -2111111111;
		len++;
		nbr *= -1;
	}
	while (nbr > 9)
	{
		len++;
		nbr /= 10;
	}
	return (len);
}

static void	ft_put_in_tab(int nbr, char *result, int len)
{
	if (nbr < 0)
	{
		*(result - (len - 1)) = '-';
		if (nbr == -2147483648)
		{
			*result = '8';
			ft_put_in_tab(214748364, result - 1, len);
			return ;
		}
		nbr *= -1;
	}
	if (nbr >= 10)
		ft_put_in_tab(nbr / 10, result - 1, len);
	*result = (nbr % 10) + '0';
}

char	*ft_itoa(int nbr)
{
	int		len;
	char	*result;

	len = ft_len(nbr);
	result = (char *)malloc(sizeof(char) * (len + 1));
	if (result == NULL)
		return (NULL);
	ft_put_in_tab(nbr, result + (len - 1), len);
	result[len] = 0;
	return (result);
}
