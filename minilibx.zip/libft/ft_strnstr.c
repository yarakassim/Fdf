/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/11 17:07:53 by eli               #+#    #+#             */
/*   Updated: 2021/05/20 14:11:17 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *big, const char *little, size_t len)
{
	int				i;
	char			*ptr;
	unsigned int	len2;

	if (*little == 0 || little == 0)
		return ((char *)big);
	while (*big && len-- > 0)
	{
		i = 0;
		if (*big == little[i])
		{
			len2 = len + 1;
			ptr = (char *)big;
			while (*big == little[i] && *big && little[i] && len2-- > 0)
			{
				big++;
				i++;
			}
			if (little[i] == 0)
				return (ptr);
			big = ptr;
		}
		big++;
	}
	return (NULL);
}
