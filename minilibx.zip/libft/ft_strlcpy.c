/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/28 17:01:29 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 13:03:35 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t size)
{
	size_t			result;
	unsigned int	i;

	result = 0;
	i = 0;
	if (!src)
		return (0);
	result = ft_strlen(src);
	if (!dst)
		return (result);
	if (dst && size > 0)
	{
		while (i < size - 1 && size > 1 && *src && dst)
		{
			*dst = *src;
			dst++;
			src++;
			i++;
		}
		if (dst)
			*dst = '\0';
	}
	return (result);
}
