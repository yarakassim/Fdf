/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/08 11:59:37 by eli               #+#    #+#             */
/*   Updated: 2021/05/20 14:01:23 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	size_t					i;
	const unsigned char		*src2;
	unsigned char			*dest2;

	src2 = (unsigned char *)src;
	dest2 = (unsigned char *)dest;
	if (dest2 < src2)
	{
		i = 0;
		while (i < n && &src2[i])
		{
			dest2[i] = src2[i];
			i++;
		}
	}
	else if (dest2 > src2)
	{
		i = n;
		while (i > 0 && &src2[i - 1])
		{
			dest2[i - 1] = src2[i - 1];
			i--;
		}
	}
	return (dest);
}
