/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/13 17:06:13 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 13:01:02 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	unsigned int	size;
	unsigned int	i;
	char			*result;

	if (!s)
		return (NULL);
	result = NULL;
	if (ft_strlen(s) >= len)
		size = len;
	else
		size = ft_strlen(s);
	if (start >= ft_strlen(s))
		size = 0;
	result = malloc(sizeof(char) * size + 1);
	if (result == NULL)
		return (NULL);
	i = 0;
	while (i < size)
	{
		result[i] = s[start + i];
		i++;
	}
	result[i] = 0;
	return (result);
}
