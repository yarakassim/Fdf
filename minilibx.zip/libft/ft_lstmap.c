/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/21 18:42:54 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 13:36:06 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *))
{
	t_list		*result;
	t_list		*begin;

	if (lst == NULL)
		return (NULL);
	begin = ft_lstnew((*f)(lst->content));
	if (begin == NULL || !lst || !f)
		return (NULL);
	result = begin;
	lst = lst->next;
	while (lst)
	{
		result->next = ft_lstnew((*f)(lst->content));
		if (result->next == NULL)
		{
			ft_lstclear(&begin, del);
			return (NULL);
		}
		result = result->next;
		lst = lst->next;
	}
	result->next = NULL;
	return (begin);
}
