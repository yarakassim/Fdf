/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/11 11:05:08 by eazenag           #+#    #+#             */
/*   Updated: 2021/05/20 14:06:34 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *src)
{
	char	*cpy;
	char	*ptr;

	cpy = (char *)malloc(sizeof(char) * (ft_strlen(src) + 1));
	ptr = cpy;
	if (cpy == NULL)
		return (NULL);
	while (*src)
	{
		*cpy = *src;
		cpy++;
		src++;
	}
	*cpy = '\0';
	cpy = ptr;
	return (cpy);
}
