/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/13 18:37:51 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 17:05:46 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>

static unsigned int	ft_count_word(char const *str, char c)
{
	unsigned int	word;

	if (!str || !(*str))
		return (0);
	if (c == '\0')
		return (1);
	word = 0;
	if (*str && *str != c)
	{
		word++;
		str++;
	}
	while (*str)
	{
		if (*str != c && *(str - 1) == c)
			word++;
		str++;
	}
	return (word);
}

static unsigned int	ft_count_letters(char const *str, char c)
{
	unsigned int	letters;

	while (*str == c)
		str++;
	letters = 0;
	if (c == 0)
		return (ft_strlen(str) + 1);
	while (*str)
	{
		if (*str == c)
			return (letters + 1);
		letters++;
		str++;
	}
	return (letters + 1);
}

static int	ft_put_in_tab(char **split, char const *str, char c)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (*str)
	{
		while ((*str == c) && (*(str + 1) == c))
			str++;
		if (*str == c && j > 0 && *(str + 1))
		{
			split[i][j] = '\0';
			i++;
			j = 0;
			split[i] = malloc(sizeof(char) * ft_count_letters(str + 1, c));
			if (split[i] == NULL)
				return (-1);
		}
		if (*str != c && *str && j++ >= 0)
			split[i][j - 1] = *str;
		str++;
	}
	if (j > 0)
		split[i][j] = '\0';
	return (0);
}

static void	*ft_free_n_quit(char **split)
{
	char	**ptr;

	ptr = split;
	while (*split)
	{
		free(*split);
		split++;
	}
	free(ptr);
	return (NULL);
}

char	**ft_split(char const *s, char c)
{
	char			**split;
	unsigned int	len;

	if (!s)
		return (NULL);
	len = ft_count_word(s, c);
	split = (char **)ft_calloc(len + 1, sizeof(char *));
	if (split == NULL)
		return (NULL);
	if (!len)
	{
		*split = NULL;
		return (split);
	}
	split[0] = (char *)malloc(sizeof(char) * ft_count_letters(s, c));
	if (split[0] == NULL)
		return (ft_free_n_quit(split));
	if (ft_put_in_tab(split, s, c) == -1)
		return (ft_free_n_quit(split));
	split[len] = NULL;
	return (split);
}
