/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/13 17:27:26 by eli               #+#    #+#             */
/*   Updated: 2021/05/21 13:20:44 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	ft_cpy_strings(char *result, const char *s1, const char *s2)
{
	unsigned int			i;

	i = 0;
	while (s1 && s1[i])
	{
		*result = s1[i];
		result++;
		i++;
	}
	i = 0;
	while (s2 && s2[i])
	{
		*result = s2[i];
		result++;
		i++;
	}
	*result = '\0';
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	char			*result;
	unsigned int	len1;
	unsigned int	len2;
	unsigned int	len;

	len1 = 0;
	len2 = 0;
	if (s1)
		len1 = ft_strlen(s1);
	if (s2)
		len2 = ft_strlen(s2);
	len = len1 + len2;
	if (len == 0)
	{
		result = (char *)malloc(sizeof(char));
		*result = '\0';
		return (result);
	}
	result = (char *)malloc(sizeof(char) * (len + 1));
	if (result == NULL)
		return (NULL);
	ft_cpy_strings(result, s1, s2);
	return (result);
}
