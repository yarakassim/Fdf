/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/13 17:48:36 by eli               #+#    #+#             */
/*   Updated: 2021/05/20 14:12:37 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_isset(const char c, const char *set)
{
	while (*set)
	{
		if (c == *set)
			return (1);
		set++;
	}
	return (0);
}

char	*ft_strtrim(char const *s1, char const *set)
{
	unsigned int	start;
	unsigned int	end;
	size_t			len;
	char			*result;

	if (s1 == NULL)
		return (NULL);
	if (*set == 0)
		return (ft_strdup(s1));
	start = 0;
	end = ft_strlen(s1) - 1;
	if (*s1 == 0)
		end = 0;
	while (ft_isset(s1[start], set))
		start++;
	while (s1[start] && ft_isset(s1[end], set))
		end--;
	len = end - start + 1;
	if (end <= start || s1[start] == 0)
		len = 0;
	result = malloc(sizeof(char) * (len + 1));
	if (result == NULL)
		return (NULL);
	ft_strlcpy(result, &s1[start], len + 1);
	return (result);
}
