/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eazenag <eazenag@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/07/03 15:27:30 by eli               #+#    #+#             */
/*   Updated: 2021/07/23 14:47:26 by eazenag          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FDF_H
# define FDF_H

# include <sys/types.h>
# include <sys/stat.h>
# include <fcntl.h>
# include  "../minilibx/mlx.h"
# include <stdlib.h>
# include <stdio.h>
# include <string.h>
# include <unistd.h>
# include <math.h>
# include "../get_next_line/get_next_line.h"
# include "../libft/libft.h"

# define ESC_KEY 65307

typedef struct s_mlx
{
	void	*ptr;
	void	*window;
	int		nbr_lines;
	int		nbr_col;
	void	*image;
	int		*data;
	int		size_imX;
	int		size_imY;
	int		higher;
	int		lower;
	int		**tab;
	double	beginX;
	double	beginY;
	double	Xa;
	double	Ya;
	int		**tab_map;
	int		color;
	double	unitX;
	double	unitY;
	double	unitZ;
}			t_mlx;

int		ft_quit(int keycode, t_mlx *map);
int		ft_free(t_mlx *map);
void	ft_draw_map(t_mlx *map);

int		ft_config_units(t_mlx *map);
int		ft_create_window(t_mlx *map, int nbr_lines, int nbr_col);
void	ft_define_size_im(t_mlx *map, int nbr_lines, int nbr_col);

void	draw_plane_line(t_mlx *map);
void	ft_draw(t_mlx *map, int **tab, int height, int n);
void	ft_draw_small_line(t_mlx *map, double Xa, double Ya );
void	ft_draw_up_down_line(t_mlx *map, int height);

int		**ft_map(char *av, t_mlx map);
void	ft_fill_tab(int *tab, char *line);
int		ft_count_line(char *av, t_mlx *map);
int		ft_maplen(char *s);
void	ft_find_higher(char *str, t_mlx *map);

#endif
